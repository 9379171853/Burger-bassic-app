import React from 'react';
const aux = (props) => props.children;

export default aux;